package com.union.example.common.vo;

import com.union.example.common.utils.Util;

public class CommonVo
{
  private int pgno = 1;

  private int lists = 0;

  private int pageSize = 5;
  private String keyfield;
  private String keyword;
  private String schStartDate;
  private String schEndDate;
  private int firstRecordIndex;

  public int getPgno()
  {
    return this.pgno;
  }

  public void setPgno(int pgno)
  {
    this.pgno = pgno;
  }

  public int getLists()
  {
    return this.lists == 0 ? 10 : this.lists;
  }

  public void setLists(int lists)
  {
    this.lists = lists;
  }

  public int getPageSize()
  {
    return this.pageSize;
  }

  public void setPageSize(int pageSize)
  {
    this.pageSize = pageSize;
  }

  public String getKeyfield()
  {
    return Util.StringReplaceSpecialCharacter(this.keyfield);
  }

  public void setKeyfield(String keyfield)
  {
    this.keyfield = keyfield;
  }

  public String getKeyword()
  {
    return this.keyword;
  }

  public void setKeyword(String keyword)
  {
    this.keyword = keyword;
  }

  public String getSchStartDate()
  {
    return this.schStartDate;
  }

  public void setSchStartDate(String schStartDate)
  {
    this.schStartDate = schStartDate;
  }

  public String getSchEndDate()
  {
    return this.schEndDate;
  }

  public void setSchEndDate(String schEndDate)
  {
    this.schEndDate = schEndDate;
  }

  public int getFirstRecordIndex()
  {
    return this.firstRecordIndex;
  }

  public void setFirstRecordIndex(int firstRecordIndex)
  {
    this.firstRecordIndex = firstRecordIndex;
  }
}