package com.union.example.board.vo;

import com.union.example.common.vo.CommonVo;

public class MainBbsVo extends CommonVo
{
  private Integer no;
  private String title;
  private String content;
  private String regId;
  private String regDt;
  private String delYn;
  private String modId;
  private String modDt;

  public Integer getNo()
  {
    return this.no;
  }

  public void setNo(Integer no)
  {
    this.no = no;
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  public String getContent()
  {
    return this.content;
  }

  public void setContent(String content)
  {
    this.content = content;
  }

  public String getRegId()
  {
    return this.regId;
  }

  public void setRegId(String regId)
  {
    this.regId = regId;
  }

  public String getRegDt()
  {
    return this.regDt;
  }

  public void setRegDt(String regDt)
  {
    this.regDt = regDt;
  }

  public String getDelYn()
  {
    return this.delYn;
  }

  public void setDelYn(String delYn)
  {
    this.delYn = delYn;
  }

  public String getModId()
  {
    return this.modId;
  }

  public void setModId(String modId)
  {
    this.modId = modId;
  }

  public String getModDt()
  {
    return this.modDt;
  }

  public void setModDt(String modDt)
  {
    this.modDt = modDt;
  }

  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (this.content == null ? 0 : this.content.hashCode());
    result = 31 * result + (this.delYn == null ? 0 : this.delYn.hashCode());
    result = 31 * result + (this.modDt == null ? 0 : this.modDt.hashCode());
    result = 31 * result + (this.modId == null ? 0 : this.modId.hashCode());
    result = 31 * result + (this.no == null ? 0 : this.no.hashCode());
    result = 31 * result + (this.regDt == null ? 0 : this.regDt.hashCode());
    result = 31 * result + (this.regId == null ? 0 : this.regId.hashCode());
    result = 31 * result + (this.title == null ? 0 : this.title.hashCode());
    return result;
  }

  public boolean equals(Object obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MainBbsVo other = (MainBbsVo)obj;
    if (this.content == null) {
      if (other.content != null)
        return false;
    } else if (!this.content.equals(other.content))
      return false;
    if (this.delYn == null) {
      if (other.delYn != null)
        return false;
    } else if (!this.delYn.equals(other.delYn))
      return false;
    if (this.modDt == null) {
      if (other.modDt != null)
        return false;
    } else if (!this.modDt.equals(other.modDt))
      return false;
    if (this.modId == null) {
      if (other.modId != null)
        return false;
    } else if (!this.modId.equals(other.modId))
      return false;
    if (this.no == null) {
      if (other.no != null)
        return false;
    } else if (!this.no.equals(other.no))
      return false;
    if (this.regDt == null) {
      if (other.regDt != null)
        return false;
    } else if (!this.regDt.equals(other.regDt))
      return false;
    if (this.regId == null) {
      if (other.regId != null)
        return false;
    } else if (!this.regId.equals(other.regId))
      return false;
    if (this.title == null) {
      if (other.title != null)
        return false;
    } else if (!this.title.equals(other.title))
      return false;
    return true;
  }
}