package com.union.example.board.service;

import com.union.example.board.vo.MainBbsVo;
import java.util.List;
import org.springframework.ui.ModelMap;

public abstract interface MainBbsService
{
  public abstract List<MainBbsVo> selectMainList(MainBbsVo paramMainBbsVo, ModelMap paramModelMap)
    throws Exception;

  public abstract void insertMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract MainBbsVo selectMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract void deleteMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract void modifyMainData(MainBbsVo paramMainBbsVo)
    throws Exception;
}