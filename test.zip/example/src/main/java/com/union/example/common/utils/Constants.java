package com.union.example.common.utils;

import java.util.regex.Pattern;

public class Constants
{
  public static final String WEB_ATTACH_PATH = "/upload";
  public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", 2);
  public static final int DEFAULT_PAGE_LIST_NO = 10;
  public static final int MOBILE_PAGE_LIST_NO = 5;
  public static final int DEFAULT_PAGE_SIZE_NO = 5;
  public static final int MOBILE_PAGE_SIZE_NO = 1;
  public static final String PARAM_NAME = "no,keyfield,keyword,lists";
  public static final String[] ERROR = { "error", "오류" };

  public static final String[] SUCCESS = { "success", "성공" };

  public static final String[] INFO = { "info", "정보" };

  public static final String[] WARNING = { "warning", "주의" };
  public static final String WEB_ICON_FILE_PATH = "/assets/images/icon";
  public static final int THUMBNAIL_WIDTH = 475;
  public static final int THUMBNAIL_HEIGHT = 285;
  public static final String THUMBNAIL_WORK_SERVER_PATH = "/web-data/2016_www";
}