package com.union.example.board.service.impl;

import com.union.example.board.vo.MainBbsVo;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("mainBbsMapper")
public abstract interface MainBbsMapper
{
  public abstract List<MainBbsVo> selectMainList(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract int selectMainListCnt()
    throws Exception;

  public abstract void insertMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract MainBbsVo selectMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract void deleteMainData(MainBbsVo paramMainBbsVo)
    throws Exception;

  public abstract void modifyMainData(MainBbsVo paramMainBbsVo)
    throws Exception;
}